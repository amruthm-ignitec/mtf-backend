import os
from openai import AzureOpenAI

endpoint = "https://gptdonoriq.openai.azure.com/"  
deployment = "text-embedding-3-large" 
subscription_key = "2D6CYxt7YHn666WdxAomZTTyk2jo4HpTEhi9Iy4Nw2k3w18O4DSRJQQJ99BAACYeBjFXJ3w3AAABACOG003z"  


client = AzureOpenAI(
    api_key=endpoint,  
    api_version="2023-05-15-preview",
    azure_endpoint=endpoint
)

embedding = client.embeddings.create(
  model=deployment, # Replace with your model deployment name
  input="Attenion is all you need",
  encoding_format="float" 
)

print(embedding)

# # Get the list of deployments
# try:
#     # List deployments to see what's available
#     deployments = client.deployments.list()
#     print("Available deployments:")
#     for deployment in deployments:
#         print(f"- {deployment.model} : {deployment.id}")
# except Exception as e:
#     print(f"Error listing deployments: {e}")

# # Test with your actual deployment name
# try:
#     response = client.chat.completions.create(
#         # Replace ACTUAL_DEPLOYMENT_NAME with what you see in Azure portal
#         model="donoriq-deployment",  
#         messages=[{"role": "user", "content": "Hello"}]
#     )
#     print("Success!")
# except Exception as e:
#     print(f"Error: {e}")