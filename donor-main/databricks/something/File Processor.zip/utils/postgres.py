import psycopg2
import json
import io
import os
import pandas as pd
from datetime import datetime
import ast
import time
from sqlalchemy import create_engine
from sqlalchemy import text
import pandas as pd
from sqlalchemy import Table, Column, String, JSON, DateTime, MetaData, insert, and_, select


def sqlalchemy_connection():

    engine = create_engine("postgresql://doadmin:AVNS_Knn2pH6Rz0s3-GlVSu9@postgresql-nyc3-donoriq-do-user-3568495-0.j.db.ondigitalocean.com:25060/defaultdb")
    return engine


def update_db_data_prod_sqlalchemy(engine, uid, serology_res, culture_res, topic_summary_res):
    current_datetime = datetime.now()
    metadata = MetaData()
    user_table = Table(
        "dc_data_prod",
        metadata,
        Column('datetime', DateTime),
        Column('uid', String(30), primary_key=True),
        Column('serology_results', JSON),
        Column('culture_results', JSON),
        Column ('ts_results' ,JSON)
    )
    stmt = insert(user_table).values(datetime = current_datetime, uid=uid, serology_results = serology_res, culture_results = culture_res, ts_results = topic_summary_res)
    try:
        compiled = stmt.compile()
        with engine.connect() as conn:
            result = conn.execute(stmt)
            conn.commit()
        return "Success"
    except Exception as e:
        print('Error: ', e)
        return e
    

def update_db_meta_prod_sqlalchemy_1(engine, uid, donor_id, job_id, donor_details, status):
    current_datetime = datetime.now()
    metadata = MetaData()
    user_table = Table(
        "dc_meta_prod",
        metadata,
        Column('datetime', DateTime), 
        Column('uid', String(30), primary_key=True),
        Column('donor_id', String(30)),
        Column('job_id', String(30)),
        Column ('donor_details' ,JSON),
        Column('status', String(30))
    )
    stmt = insert(user_table).values(datetime = current_datetime, uid=uid, donor_id=donor_id, job_id=job_id, donor_details=donor_details, status=status)
    try:
        compiled = stmt.compile()
        with engine.connect() as conn:
            result = conn.execute(stmt)
            conn.commit()
        return True
    except Exception as e:
        print('Error: ', e)
        return False
    
def update_db_meta_prod_sqlalchemy(engine, uid, donor_id, job_id, donor_details, status):
    current_datetime = datetime.now()
    metadata = MetaData()

    # Define the dc_meta table structure (this won't recreate the table)
    dc_meta_prod = Table(
        "dc_meta_prod",
        metadata,
        Column('datetime', DateTime), 
        Column('uid', String(30), primary_key=True),
        Column('donor_id', String(30)),
        Column('job_id', String(30)),
        Column('donor_details', JSON),
        Column('status', String(30))
    )

    stmt = select(dc_meta_prod).where(
        and_(
            dc_meta_prod.c.donor_id == donor_id,
            dc_meta_prod.c.status == 'Uploaded'
        )
    ).order_by(dc_meta_prod.c.datetime.desc()).limit(1)

    try:
        with engine.connect() as connection:
            result = connection.execute(stmt).fetchone()

            if result:
                update_stmt = (
                    dc_meta_prod.update()
                    .where(
                        and_(
                            dc_meta_prod.c.donor_id == donor_id,
                            dc_meta_prod.c.datetime == result.datetime, 
                            dc_meta_prod.c.status == 'Uploaded'
                        )
                    )
                    .values(
                        datetime=current_datetime,  
                        uid=uid,  
                        job_id=job_id, 
                        donor_details=donor_details, 
                        status=status  
                    )
                )
                connection.execute(update_stmt)
                connection.commit()

                print(f"Row updated successfully for donor_id {donor_id} with uid {uid}.")

            else:
                print(f"No matching row found for donor_id {donor_id} with status 'Uploaded'.")
                update_db_meta_prod_sqlalchemy_1(engine, uid, donor_id, job_id, donor_details, status)
        return True

    except Exception as e:
        print(f"Error during update: {e}")
        return False