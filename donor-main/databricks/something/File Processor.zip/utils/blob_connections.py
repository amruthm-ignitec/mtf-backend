import re
import io
import os

from azure.storage.blob import BlobServiceClient, ContentSettings
from PyPDF2 import PdfReader

def blob_connection():
    connection_string = "DefaultEndpointsProtocol=https;AccountName=donoraidevsa;AccountKey=rH0YuygSiPu5P7kz3ulEqMDKPM95LcPIPc7BQnRmcM1N5Q7jp7B3OUyOFcSOrUn4PkBJuW+9tUJG+AStehjXtA==;EndpointSuffix=core.windows.net"  # Replace with your actual connection string
    container_name = "blobcontainerprod-donorai"
    return connection_string, container_name


def mount_blob(connection_string, container_name):

    blob_service_client = BlobServiceClient.from_connection_string(connection_string)
    container_client = blob_service_client.get_container_client(container_name)

    return (blob_service_client, container_client)


def get_pdf_files(container_client, virtual_dir_path):
    blobs_list = container_client.list_blobs(name_starts_with=virtual_dir_path)
    pdf_files = [blob.name for blob in blobs_list if blob.name.endswith('.pdf')]
    return pdf_files


def load_pdf_from_blob_storage(blob_client, dbfs_path):   
    '''
    Downloads PDF file from blob container to DBFS
    ''' 
    try:
                
        with io.BytesIO() as pdf_stream:
            download_stream = blob_client.download_blob()
            download_stream.readinto(pdf_stream)
            pdf_stream.seek(0)
            
            # Save PDF to DBFS
            with open(dbfs_path, 'wb') as f:
                f.write(pdf_stream.read())         

            return True

    except Exception as e:
        print(f"An error occurred while importing your PDF from Blob: {e}")
        return False
    

def uploadToBlobStorage(blob_client, dbfs_path):
    try:
        content_settings = ContentSettings(content_type="application/pdf")
        with open(dbfs_path, "rb") as data:
            blob_client.upload_blob(data, content_settings=content_settings, overwrite=True)
        return True
    except Exception as e:
        print(f"An error occurred while uploading your PDF to Blob: {e}")
        return False
    

def renameBlob(old_blob_client, new_blob_client):
    try:
        new_blob_client.start_copy_from_url(old_blob_client.url)
        old_blob_client.delete_blob()
        return True
    except Exception as e:
        print(f"An error occurred while renaming your blob: {e}")
        return False
    
def move_to_not_processed(blob_client, container_name, blob_service_client, full_blob_name, donor_id, reason):
    """
    Moves a file to the 'NOT PROCESSED' folder for a given reason.
    """
    blob_name = full_blob_name.split('/')[-1]
    print(f"{reason} Skipping this file.\nPushing file into 'NOT_PROCESSED'.\nID: {donor_id}")
    new_blob_name = 'NOT_PROCESSED/' + blob_name
    new_blob_client = blob_service_client.get_blob_client(container=container_name, blob=new_blob_name)
    renameBlob(blob_client, new_blob_client)


def check_and_process_file(blob_client, container_name, blob_service_client, full_blob_name, dbfs_path, max_size_mb=450, max_pages=2000):
 
    blob_name = full_blob_name.split('/')[-1]
    donor_id = blob_name.split(' ')[0]

    blob_properties = blob_client.get_blob_properties()
    file_size_mb = blob_properties.size / (1024 * 1024)
    print('File Size: ', file_size_mb, 'MB')

    if file_size_mb > max_size_mb:
        move_to_not_processed(blob_client, container_name, blob_service_client, full_blob_name, donor_id, "File size exceeded!")
        return {"status": "error", "message": "File size exceeded!"}
    print("Downloading file from blob storage")
    load_status = load_pdf_from_blob_storage(blob_client, dbfs_path)
    if not load_status:
        move_to_not_processed(blob_client, container_name, blob_service_client, full_blob_name, donor_id, "Error loading PDF from blob storage.")
        return {"status": "error", "message": "Error loading PDF from blob storage."}

    # page_doc_list, doc_list = data_load(dbfs_path, 'pdfplumber')
    page_len = PdfReader(dbfs_path).pages
    print('No. of Pages: ', len(page_len))
    if len(page_len) > max_pages:
        move_to_not_processed(blob_client, container_name, blob_service_client, full_blob_name, donor_id, "Pages limit exceeded!")
        return {"status": "error", "message": "Pages limit exceeded!"}

    return {"status": "success"}
