import os

import langchain 
from langchain_openai import AzureChatOpenAI
from langchain_openai import AzureOpenAIEmbeddings
# Define the keys and endpoints



def llm_setup():

    os.environ["OPENAI_API_TYPE"] = "azure"
    os.environ["OPENAI_API_BASE"] = "https://gptdonoriq.openai.azure.com/"
    os.environ["OPENAI_API_KEY"] = "2D6CYxt7YHn666WdxAomZTTyk2jo4HpTEhi9Iy4Nw2k3w18O4DSRJQQJ99BAACYeBjFXJ3w3AAABACOG003z" 
    os.environ["AZURE_OPENAI_CHAT_DEPLOYMENT_NAME"] = "gpt-4o" 
    os.environ["OPENAI_API_VERSION"] = "2023-07-01-preview" 

    # Create an instance of Azure OpenAI 
    llm = AzureChatOpenAI(
        deployment_name=os.environ["AZURE_OPENAI_CHAT_DEPLOYMENT_NAME"],
        azure_endpoint=os.environ["OPENAI_API_BASE"],
        temperature=0
    )
    embeddings = AzureOpenAIEmbeddings(azure_deployment='text-embedding-3-large',
                                    azure_endpoint="https://gptdonoriq.openai.azure.com/openai/deployments/text-embedding-3-large/embeddings?api-version=2023-05-15",
                                    openai_api_key="2D6CYxt7YHn666WdxAomZTTyk2jo4HpTEhi9Iy4Nw2k3w18O4DSRJQQJ99BAACYeBjFXJ3w3AAABACOG003z",
                                    openai_api_version="2023-05-15",
                                    chunk_size=1)
    return llm, embeddings